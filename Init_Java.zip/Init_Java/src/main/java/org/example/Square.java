package org.example;

public class Square extends Rectangle {
    public Square(double cote) {
        super(cote, cote);
    }
}
